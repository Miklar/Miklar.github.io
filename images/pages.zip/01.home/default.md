---
title: Home
---

Premiere for first track Hulls from upcoming album # 7, probably titled Comma.

![](http://www.loneydear.com/bilder2016/emilhands2016pressimage.jpg)

[Press resource: image use this.](http://http://www.loneydear.com/bilder2016/emilhands2016pressimage.tiff)

Video shoot w Mats Udd, and Folke S in picture.


![](loney_svart.jpg)

Loney dear have been active since 2002. Around six or seven records have been made and released since. RIVER FONTANA (out of sale) (2003). CITADEL BAND (2004) (never really released) SOLOGNE 2004, LONEY NOIR (2005, 2007), DEAR JOHN (2009), HALL MUSIC (2011). [Re-releasing and premiering catalogue on vinyl. Order here.](http://loneydear.tictail.com/) In the last years some strange tracks have been released digitally. [The best one is the Love Hurts cover Emil made for Emmylou and the Polar Music Prize.](https://open.spotify.com/album/5E7XNoyMP5QvuynE8GVrCq)

[![](love%20hurts%203.jpg)](http://open.spotify.com/album/5E7XNoyMP5QvuynE8GVrCq)

[This extended version of the rewound version of "What have I become" (HALL MUSIC) is pretty great too. Lie down and drift away.](https://open.spotify.com/track/2SLddhFcokKD61X2ip6QXf)

 ---------------------------------------------------------

Reach Emil: [nilsemil@gmail.com](mailto:nilsemil@gmail.com) Loney dear: [marie@dimberg.com](mailto:marie@dimberg.com) Booking: [robin@luger.se](mailto:robin@luger.se)

![](malin_david.jpg)

Order these shirts from [SHOP](http://loneydear.tictail.com).