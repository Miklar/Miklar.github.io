---
title: 'Past concerts'
---

12 FEB 2016. Kulturhuset HÖRSALEN. Strong six piece band.
SOLD OUT!!Possibly extra shows announced here:

4th of MARCH. Zürich. Ensemble show with special guest Konrad Agnas and wind orchestra.

memory shows:

17 DEC 2015. Drömmen om Amerika. Loney dear på Fasching med Oskar Schönning, Konrad Agnas, Losefin Runsteen, Johan Graden och Thomas Backman.

GÖTEBORG 27 SEPT. Some kind of solo concert with special guest Emanuel Lundgren IFB. TICKETS/BILJETTER HERE Tickets limited to 140. Address: OLOF PALMES PLATS. FOLK at FOLKTEATERN.

LIDKÖPING 29 OKT

VARA 27 NOV

BLIDÖSUND 1 SEPT. best ever.

SIGTUNA LITTERATURFESTIVAL 21 AUG

AMSTERDAM,15 AUG

STOCKHOLM KULTURFESTIVAL 12 AUG. Audience 7000.

SUNDBYBERG ALLAKTIVITETSHUSET 17 JUN SOLD OUT.

GÖTEBORG Engelska kyrkan 14th of June 20:00. SOLD OUT.

29 MAJ. Sold out Linköping show at Babettes.

A solo concert with guests at Teater Pero 24th of April. Tickets sold out very first day, one month ahead!

![](loney%20pero%20pinky2.jpg)

![](concerts.jpg)


24 MAY. Homecoming (JÖNKÖPING), small show with quintet in Jönköping. Konrad Agnas, David Lindvall, Malin Ståhlberg, Simon Ljungman. 

2014 NOVEMBER. Orchestral tour with Norrbottens kammarorkester.



MAY. Concert with Järfälla Manskör, with my teen idols Per Texas Johansson and Mattias Ståhl. Sold out. 

31 JANUARI 2014. At new concert house Spira in Jönköping. 
There's even a whole Småland tour around these dates. Gnosjö, Mullsjö, Sävsjö and other very very small places. Sehr cool.

21 FEB. Victoriateatern Malmö. Sold out.

2013 part II.


30 november 2013. MARIEFRED, at GRAFIKENS HUS. Sold out.

PARIS: A NIGHT WITH FANTÔMAS.

GÖTEBORG. AUGUST 1st. Small possibly magic probably solo show, small room at JAZZHUSET

FLEVO / HOLLAND AUGUST 17th. Duo show with Bläckfisken.

SOKNDAL NORWAY SEPT 21th. Rural norway was a treat.

SUPERFRIENDLY ORCHESTRAL show in MAJORNAS MISSIONSKYRKA 5th OCTOBER. Sold out.

 



LINKÖPING may 2013. small small.

JÖNKÖPING may 2013. small small.

2013 part I. Recording and recovering. Man, im worn out.

2012:

19 - 25 januari	Holland
26 januari, Gent	Belgien
27 januari, Paris	Frankrike
28 - 29 januari, Bryssel	Belgien

16-17 februari, Bylarm Oslo	Norge
18 februari, St-Malo, La Route Du Rock Festival	Frankrike
19 februari, Bristol, Louisiana	Storbritannien
20 februari, London, Bush Hall	Storbritannien
22 februari, Stuttgart, Schocken	Tyskland
23 februari, Wien, Rhiz	Österrike
24 februari, Conegliano, Apartaménto Hoffman	Italien
25 februari, Zurich, El Lokal	Schweiz
26 februari, Munster, Gleis 22	Tyskland
27 februari, Berlin, Roter Salon	Tyskland
28 februari, Hamburg, Knust	Tyskland
29 februari, Copenhagen, Ideal Bar	Danmark
1-3 mars, Moskva, 16 Ton	Ryssland
10 - 15 mars, rep i Jönköping	Jönköping
19 mars, Los Angeles, CA, Bootleg Bar	USA
20 mars, San Francisco, CA, Bottom of the Hill	USA
22 mars, Portland, OR, Mississippi Studios	USA
23 mars,Vancouver, BC, Media Club	Kanada
24 mars, Seattle, WA, Chop Suey	USA
27 mars,Minneapolis, MN, First Avenue	USA
28 mars, Chicago, IL, The Metro	USA
29 mars, Cleveland, OH, Beachland Ballroom	USA
31 mars, New York, NY, Webster Hall	USA
1 april, Boston, MA, Paradise Rock Club	USA
2 april, Philadelphia, PA, Union Transfer	USA
3 april, Washington, DC, 9:30 Club	USA
4 april,	USA
5 april, Asheville, NC, The Orange Peel	USA
6 april, Chatanooga, TN, Track 29	USA
7 april, Atlanta, GA, Variety Playhouse	USA
21 april, Paris	Frankrike
28 april, Göteborg, Pustervik	Göteborg
5 maj, London	Storbritannien
6 maj, Manchester	Storbritannien
7 maj, Glasgow	Storbritannien
8 maj, Belfast?	Irland
9 maj, Dublin	Irland
10 maj, Cork	Storbritannien
11 maj, Cardiff	Storbritannien
12 maj, Bighton	Storbritannien
14 maj, Amsterdam	Nederländerna
15 maj, Barcelona	Spanien
16 maj, Madrid	Spanien
17 maj, Murcia	Spanien
19 maj, Black Box Piteå	Piteå
2 juni, Siestafestivalen Hässleholm	Hässleholm
24 - 26 juni, Festspillene, Lofoten	Norge
29 - 1 juli, Trondheim	Norge
3 - 4 juli, Montreal Jazz Festival	Kanada
5 - 6 juli, River to river Festival	New York
7 - 11 juli, Legedary Horse shoe tavern, Quebec City Festival 
25 - 26 juli, Storsjöyran festival	Östersund
29 - 30 juli, Slussens Pensionat	Orust
2 - 4 augusti, Urkult festival	Sollefteå
4 - 5 augusti, Härnta festival Härnösand
8 augusti, Frizon	Kunla
9 -10 augusti, Haldern Pop festival	Tyskland
16 augusti Green man festival	Storbritannien
17-18 augusti, Sunday Sundae Festival	Storbritannien
21-22 augusti, Malmöfestivalen	Malmö
23 september, Sweden Aid Orchestra	Gävle
11-13 oktober, Les Boriales Festival	Frankrike
13 - 14 oktober, Jönköpingsgalan	Jönköping
26 oktober, Bjärka Säby	Linköping
9 november,Lokomotivet, Eskilstuna	Eskilstuna
10 nov Imanuelskyrkan, Jkpg - Gnosjö mk	Jönköping
19-20 november, Bushwick, Malmö	Malmö
23 december, Järstorps missionshus	Jönköping

Oct 2011 N.Y, Euro-tour

Nov 2011 US-tour. Do


Sep 10 [Union Chapel w/Wildbirds and Peacedrums](http://music.myspace.com/index.cfm?fuseaction=music.showDetails&friendid=33260985&Band_Show_ID=38548075) London
Sep 11 [End of the Road Festival](http://music.myspace.com/index.cfm?fuseaction=music.showDetails&friendid=33260985&Band_Show_ID=38549625) North Dorset

18 sept Fortaleza, Órbita
19 sept Recife, No Ar Coquetel Molotov
23 sept Buenos Aires, La Trastienda, ARGENTINA
25 sept São Paulo, SESC Pompéia
26 sept POA 26/09 BECO (spanish riddle?)

**U.S. Tour** 
Sep 30 [Casbah](http://music.myspace.com/index.cfm?fuseaction=music.showDetails&friendid=33260985&Band_Show_ID=38550109) San Diego
Oct 01 [Troubador](http://music.myspace.com/index.cfm?fuseaction=music.showDetails&friendid=33260985&Band_Show_ID=38550110) Los Angeles
Oct 02 [Slim’s](http://music.myspace.com/index.cfm?fuseaction=music.showDetails&friendid=33260985&Band_Show_ID=38550111) San Francisco
Oct 03 [Doug Fir Lounge](http://music.myspace.com/index.cfm?fuseaction=music.showDetails&friendid=33260985&Band_Show_ID=38550112) Portland, Oregon
Oct 04 [Chop Suey](http://music.myspace.com/index.cfm?fuseaction=music.showDetails&friendid=33260985&Band_Show_ID=38550113) Seattle
Oct 06 [Biltmore Cabaret](http://music.myspace.com/index.cfm?fuseaction=music.showDetails&friendid=33260985&Band_Show_ID=38550114) Vancouver
Oct 09 [7th Street Entry](http://music.myspace.com/index.cfm?fuseaction=music.showDetails&friendid=33260985&Band_Show_ID=38550115) Minneapolis
Oct 10 [Bottom Lounge](http://music.myspace.com/index.cfm?fuseaction=music.showDetails&friendid=33260985&Band_Show_ID=38550116) Chicago
Oct 11 [Grog Shop](http://music.myspace.com/index.cfm?fuseaction=music.showDetails&friendid=33260985&Band_Show_ID=38550117) Cleveland, Ohio
Oct 12 [Legendary Horseshoe Tavern](http://music.myspace.com/index.cfm?fuseaction=music.showDetails&friendid=33260985&Band_Show_ID=38550118) Toronto
Oct 13 [il Motore](http://music.myspace.com/index.cfm?fuseaction=music.showDetails&friendid=33260985&Band_Show_ID=38550119) Montreal, Quebec
Oct 14 [Great Scott](http://music.myspace.com/index.cfm?fuseaction=music.showDetails&friendid=33260985&Band_Show_ID=38550120) Boston
Oct 15 [Bowery Ballroom](http://music.myspace.com/index.cfm?fuseaction=music.showDetails&friendid=33260985&Band_Show_ID=38550121) New York
Oct 16 [Maxwells](http://music.myspace.com/index.cfm?fuseaction=music.showDetails&friendid=33260985&Band_Show_ID=38550124) Hoboken, New Jersey
Oct 17 [Johnny Brendas](http://music.myspace.com/index.cfm?fuseaction=music.showDetails&friendid=33260985&Band_Show_ID=38550125) Philadelphia

09 aug 2009 22:00 Havenkwartier Deventer 
13 aug 2009 20:00 Way Out West Festival Göteborg
14 aug 2009 20:00 Haldern Pop Festival Haldern 
16 aug 2009 20:00 Malmöfestivalen Malmö
02 sep 2009 20:00 De Duif Amsterdam, NL 
03 sep 2009 20:00 Tivoli Utrecht, NL 
04 sep 2009 20:00 Watt Rotterdam, NL 
05 sep 2009 20:00 Great Wide Open festival Vlieland 
06 sep 2009 20:00 Mezz Breda, NL

Jul 01 Franz Club/Kulturbraueri Berlin
Jul 08 Jönköping 

13 June Where The Action is, Stockholm
01 July Franz Club/Kulturbraueri, Berlin
10 Sept. Union Chapel, London (with Wildbirds and Peacedrums)

4 May Kung Fu Necktie Philadelphia, Pennsylvania
5 May Music Hall of Williamsburg Brooklyn, New York
6 May Great Scott Boston, Massachusetts
7 May il Motore Montreal, PQ, Quebec
8 May Rivoli Toronto, ON, Ontario
9 May Schuba’s Tavern Chicago, Illinois
10 May Cedar Cultural Center Minneapolis, MN, Minnesota
13 May Crocodile Café Seattle, Washington
14 May Doug Fir Lounge Portland, Oregon
15 May Bottom of the Hill San Francisco, California
16 May Spaceland Los Angeles, California
17 May UCSD San Diego, California
22 May Korjaamo Helsinki

26 Mar Herrgårn Linköping. My birthday. Got two cakes plus one digital.
27 Mar Umeå Open Umeå. 
28 Mar Debaser Medis Stockholm. Great one.
1 Apr Pustervik Gothenburg.
2 Apr Parkteatret Oslo
3 Apr Hulen Bergen
4 Apr Debaser Malmö
5 Apr Lilla Vega Copenhagen
6 Apr Voxhall Århus
8 Apr U&G Turmzimmer Hamburg
9 Apr Knaack Berlin
11 Apr  Motel Mozaique Festival Rotterdam. awesome.
12 Apr Doornroosje Nijmegan.
14 Apr The Scala London
15 Apr Night and Day Manchester. 
16 Apr Sugar Club Dublin. 
17 Apr Brudenell Social Club Leeds
18 Apr Stereo Glasgow
19 Apr Glee Club Birmingham
20 Apr Le Grand Mix Tourcoing
21 Apr Botanqiue Rotonde Brussels
22 Apr Point Ephemere Paris
24 Apr Le Romandie Lausanne
25 Apr 59:1 Münich

28 Jan 19:00 St Giles Church (headline show) London
29 Jan Iron Horse Northhampton, Massachusetts
30 Jan THE ORPHEUM THEATRE (w/Andrew Bird) Boston
31 Jan UNION HALL Brooklyn, New York
2 Feb The National (w/ Andrew Bird) Richmond, Virginia
3 Feb 9:30 Club (w/ Andrew Bird) Washington DC, Washington DC
4 Feb The Variety Playhouse (w/ Andrew Bird) Atlanta, Georgia
6 Feb The Plaza Theater (w/ Andrew Bird) Orlando, Florida
7 Feb The House of Blues (w/ Andrew Bird) New Orleans
9 Feb Spanish Moon (Headline show) Baton Rouge, Louisiana
10 Feb Rudyards Brittish Pub (Headline show) Houston, Texas
11 Feb Hailey’s (Headline show) Denton, Texas
12 Feb The Paramount Theater (w/ Andrew Bird) Austin, Texas
13 Feb The El Rey Theater (w/ Andrew B) Albuquerque, New Mexico
14 Feb The Rialto Theater (w/ Andrew Bird) Tuscon, Arizona
15 Feb Soma San Diego (w/ Andrew Bird) San Diego, California
17 Feb The Cellar Door (Headline show) Visalia, California
18 Feb The Orpheum THEATRE (w/Andrew Bird) L Angeles
19 Feb The Fillmore (w/ Andrew B) San Francisco, California
20 Feb The Fillmore (w/ Andrew B) San Francisco, California
21 Feb The Roseland Theater (w/ Andrew B) Portland, Oregon
23 Feb The Moore Theater (w/ Andrew B) Seattle, Washington
24 Feb Knitting Factory (w/ Andrew Bird) Boise, Idaho
25 Feb Murray Theater (w/ Andrew Bird) Murray, Utah
26 Feb The Ogden Theater (w/ Andrew Bird) Denver, Colorado
27 Feb Slowdown (w/ Andrew Bird) Omaha, Nebraska
28 Feb Hoyt Sherman Place (w/ Andrew Bird) Des Moines, Iowa
1 Mar Schuba’s Tavern (Headline show) Chicago, Illinois
Dec 24. X-mas concert "It IS a christmas song!"
Dec 17. Secret stockholm show.

Dec 8TH OLD BLUE LAST, London. The Line of best fit. 
Dec 10th Mercury Lounge. Another fine one! 
Dec 12th Bell House Brooklyn. Skippy turned 30 or 40.Siobhan, Ben!Sonya!
28th Nov. Oslo with Teitur. A nice trip in the dark north.

Nov 11 Münster - Gleis 22
Nov 12 Köln - Gebäude 9
Nov 13 L-Dudelange - Mighty house.
Nov 14 CH-Zürich - El Lokal.
Nov 15 Tübingen - Zoo. Ouch.
Nov 16 Wiesbaden - Schlachthof. Ouch again.
Nov 17 Day off with Paul, Matthias, Josh and Oscar.
Nov 18 Erlangen - E-Werk
Nov 19 Dresden - Beatpol
Nov 20 Leipzig - Moritzbastei
Nov 21 Bremen - Lagerhaus
Nov 22 Hamburg - Knust
Nov 23 Berlin - Maschinenhaus
Nov 24 Halle - Objekt 5
8th Nov. Stavanger. (8th?)Jul 6 2008 6:00PM Wireless Festival London
Aug 8 2008 11 PM Haldern Festival Rees-Haldern
Aug 9 2008 8:00 PM Weinturm Open Air festival Weinturm
Aug 22 2008 6:00 PM Pstereo Festival Trondheim
7 JUNI TRÄDGÅRN. Stockholm. 
26 APRIL Indigo, London, supporting Andrew Bird.

White Rabbit (US); SOKO (FR); Loney, Dear (SWE), Guillemots 
25 Years of Haldern Pop Festival MAY 07 Zürich, Abart Club 08 
München - Kleine Elser Halle 09 Dresden - Starclub
11 Frankfurt - Batschkapp 12 Berlin - Lido 13 Hamburg
Übel + Gefährlich 14 Haldern - Saal Tepfer 15 Utrecht 
16 Brussels - Les Nuits 22 MAY PARIS. La Maroquinerie

2007. 15 DEC Stockholm.

 


23 NOV Crossing Border Festival, Den Haag
22 NOV Trivoli, Utrecht
21 NOV AB Club Brussels, BE (w/ Vic Chestnut)
20 NOV Splendide, Lille (Andrew Bird, Vic Chestnut)
18 NOV Le Romandie, Lausanne (Supporting Andrew Bird)
17 NOV Le Transbordeur, Lyon (Rhesus, Andrew Bird, Syd Matters)
16 NOV La Podriere, Belfort (Supporting Andrew Bird)
14 NOV Rote Fabrik, Zurich (Supporting Andrew Bird)
13 NOV La Laterie (Les Inrock), Strabourg (Andrew Bird, Beirut
12 NOV Olympia (Les Inrocks), Paris (Devendra Banhart, 
Andrew Bird, Beirut, Remi Nicole, Loney, Dear)
11 NOV L'Antipode, Rennes (Supporting Andrew Bird)
9 NOV Koko, London (Supporting Andrew Bird)
8 NOV Academy 3, Manchester (Supporting Andrew Bird)
6 NOV Glee Club, Birmingham (Supporting Andrew Bird)
5 NOV The Arches, Glasgow (Supporting Andrew Bird)

19 OCT Iceland Airways Festival, Reykjavik
18 OCT Engine Shed, Lincoln (supporting Athlete)
17 OCT UEA, Norwich (supporting Athlete)
16 OCT Kings College, London (supporting Maps)
15 OCT Liverpool Academy, Liverpool (supporting Athlete)
14 OCT Manchester Academy, Manchester (supporting Athlete)
11 OCT Shepherds Bush, London (supporting Athlete)
10 OCT Guildhall, Southampton (supporting Athlete)
8 OCT Bristol Academy, Bristol (supporting Athlete)
7 OCT Newcastle Academy, Newcastle (supporting Athlete)
6 OCT Barrowlands, Glasgow (supporting Athlete)
4 OCT Birmingham Academy (supporting Athlete)

1 SEP ELECTRIC PICNIC, Dublin, IRL. 
19 AUG Lowlands Festival, NL
18 AUG Pukkelpop Festival, BE 
14 AUG Stockholms kulturfestival. 
10 AUG Magasinet Kumla. Tack alla, det var grymt! 
5 AUG VENLO FESTIVAL, NL 4 AUG HALDERN FESTIVAL, D 
2 AUG SUDOESTE FESTIVAL, Portugal
21 JUL Faroe Islands. Bergtakandi loney, dear

20 JUL SLOTTSFJELL FESTIVAL, Kristiansand, NO
15 JUL INDIAN SUMMER FESTIVAL, Glasgow, UK
14 JUL LATITUDE FESTIVAL, Henham Park, Southwold, Suffolk
13 JUL CONCORDE 2, Brighton, UK (w/Joan as Policewoman)
Worst.
12 JUL THE BORDERLINE, London (9 PM show), UK
 

12 JUL THE FLY
11 JUL SHEPHERD'S BUSH EMPIRE(w/Joan as Policewoman and 
Andrew Bird)
10 JUL KOKO, London, UK (w/Athlete + Maps)
9 JUL ICA, London, UK. Free ipods anyone?
7 JUL ROSKILDE FESTIVAL, Roskilde, DK
5 JUL TRÆNAFESTIVALEN, Træna, NO
1 JUL BELFORT, Les Eurockéennes de Belfort
29 JUN ACCELERATOR FESTIVAL, Stockholm, SWE
10 JUN UNION HALL, Brooklyn, New York
9 JUN WASHINGTON, DC, Black Cat (w/The Sea & Cake)
8 JUN PHILADELPHIA Theater of Living Arts (w/The Sea & Cake)
7 JUN NEW YORK, NY, Webster Hall (w/The Sea & Cake)
6 JUN BROOKLYN 5 JUN BOSTON, MA, Paradise (w/The Sea & Cake)
4 JUN MONTREAL. PQ, Club L'Ambi
3 JUN TORONTO, ON, Lee's Palace. Timeless!

2 JUN CLEVELAND, OH, Grog Shop
1 JUN CHICAGO, IL, Lakeshore Theater

30 MAY LOS ANGELES, CA, Troubadour (w/Great Northern)

29 MAY SAN FRANCISCO, CA, Independent (w/Great Northern)

   

27 MAY PORTLAND, OR, Holocene (w/Great Northern)
26 MAY SEATTLE, WA, Sasquatch
25 MAY travelling to Seattle 
24 MAY ICA London
23 MAY LEEDS, 22 MAY NOTTINGHAM, 21 MAY BIRMINGHAM, 20 MAY NEWCASTLE, 19 MAY where am I?
18 MAY BRISTOL, The cube. 
17 MAY BRIGHTON, 
16 MAY Halderen Press conference. 
15 MAY Radio France 3 recording sessions. 
O Schönning might still have a copy of it. 
13 MAY, GRONINGEN, NETHERLANDS, 
12 MAY, UTRECHT. beautiful city. 
11 MAY, NIJMEGEN 10 MAY, BRUSSELS, LES NUITS. so nice! 
9 MAY, AMSTERDAM VPRO radio 8 MAY, AMSTERDAM 
6 MAY COPENHAGEN, DEN 5 MAY MALMO, SWE 
4 MAY JONKOPING 
29 APR OSLO, BELLEVILLE, NO 
28 APR PUSTERVIK, GBG, SWE 
27 APR BERGEN, NO 
26 APR NALEN, STOCKHOLM. 

25 APR LONDON, Water Rats. 24 APR MANCHESTER 
23 APR SHORT MEMORY.. 
22 APR Whelans Dublin.
21 APR a day in paris. 
20 APR BOURGES, FRANCE 
19 APR LONDON camden crawl


US TOUR:
14 APR MINNEAPOLIS, MN First Avenue (w/ LOW) 
13 APR CHICAGO, IL Metro (w/ LOW)
12 APR DETROIT, MI Magic Stick (w/ LOW)
11 APR CLEVELAND, OH Grog Shop (w/ LOW)
10 APR WASHINGTON, DC 9:30 Club (w/ LOW)
9 APR PHILADELPHIA, PA First Unitarian (w/ LOW)
8 APR STATE COLLEGE, PA Chronic Town *HEADLINE SHOW
7 APR  SOMERVILLE, MA Somerville Theater (w/ LOW)
6 APR NEW YORK, NY Webster Hall (w/ LOW)
5 APR CANCELLED!
2 APR TALLAHASSEE, FL The Moon (w/ OF MONTREAL)
1 APR JACKSONVILLE, FL Freebird live (w/ OF MONTREAL)
31 MAR ORLANDO, FL The club at firestone (w/ OF MONTREAL)
30 MAR MIAMI, FL Studio A (w/ OF MONTREAL)
29 MAR GAINESVILLE, FL Abbey Road (w/ OF MONTREAL)
27 MAR BIRMINGHAM, AL Bottletree (w/Battles)
26 MAR birthday party in athens. 
25 MAR ATLANTA, GA Drunken Unicorn (w/Battles)
24 MAR ATHENS, GA Wuxtry Records, Instore Performance
23 MAR COLUMBIA, SC Banana Joes (w/ OF MONTREAL)
22 MAR ASHEVILLE, NC Greay Eagle Tavern (w/ OF MONTREAL)
21 MAR NASHVILLE, TN Mercy Lounge (w/ OF MONTREAL)
20 MAR NEWPORT, KY Southgate House (w/ OF MONTREAL)
19 MAR CLEVELAND, OH Beachland Ballroom (w/ OF MONTREAL)
18 MAR CHICAGO, IL Schubas Tavern *HEADLINE SHOW.
17 MAR MILWAUKEE, WI Pabst Theathe (w/ OF MONTREAL)
16 MAR MINNEAPOLIS, MN First Avenue (w/ OF MONTREAL)
15 MAR AUSTIN, TX. SXSW
14 MAR AUSTIN, TX EMO's Lounge Sub Pop Showcase 10.30 PM
12 MAR BROOKLYN, NY Union Hall (Headline show)
11 MAR BOSTON, MA Avalon Ballroom (w/ OF MONTREAL)
10 MAR NEW YORK, NY Irving Plaza (w/ OF MONTREAL)
28th February. Debut in Paris. Fleche D'or.
8th Feb. London
9th-10th Feb ByLarm Trondheim, Norway.
Et svensk funn! Publikum : ca 400 

12th January 2007. EUROSONIC, GRONINGEN 
13/1 London Notting Hill Arts Club (drownedinsound.com) 14/1 London THE SOCIAL Supporting: "The Boy Least Likely To" 
bandpool: Oskar/Oscar/Erika/Malin/Emil/Samuel/Ola  
Mon 15 Norwich, Arts Centre
Tue 16 Brighton, Komedia Wed 17 Bristol, Academy 2 Thu 18 Nottingham, Rescue Rooms
Fri 19 Glasgow, Oran Mor 
Sat 20 Aberdeen, Moshulu Sun 21 Newcastle, Academy 2
Mon 22 Manchester, Academy 3 Tue 23 Birmingham, Barfly Wed 
24 Portsmouth, Wedgewood Rooms
Thu 25 London, Scala Fri 26 The Enterprise, Camden

15 NOV. Jonkoping City Library. Schhhh!

NOV 6 London, UK. The Enterprise

Thus far, a perfect script? 
Alas not, for the power cuts out 
again, not once but twice, 
before proceedings can fully resume.

NOV 1st New York, Pianos 158 Ludlow St. Malin;


NOV 2 Bowery Ballroom, 6 Delancey St 7 PM (Sub Pop)

Thank god the really obsessive Shins fans who sold out Bowery Ballroom last night don't listen to a lot of music that isn't the Shins. Otherwise it would've been way more difficult to sidle into the beginning half of the Sub Pop showcase to see who, though there are still two more nights of ehhh-level shows to judge on, were quite possibly the highlight of this whole crazy five-day affair: the overwhelmingly pleasant and kind of brilliant Loney, Dear. One thing should probably be mentioned first: Loney, Dear's oozing Swedishness, by which I mean that his stuff is consistently pleasant but has occasional dark undertones you're maybe supposed to pick up on, and it also has that laid back, soft-rock quality of upbeat pop songs with cool jazz chords woven in. They've also got a keyboard player that looks a little like Daniel V. from Project Runway, and a requisite female vocalist/ keyboardist/tambourinist who, while we're on the subject of Swedes, might be more attractive than all of Jens Lekman's backing band put together. Considering this band has had approximately zero exposure in the US so far (though there's a healthy three or four months of prime buzzing time before the record actually drops), and that they sound as if they've been playing together for years, it's entirely possible they'll come up from out of nowhere and knock everyone on their asses, or at least, just maybe, overshadow that Shins record that comes out around the same time. L-magazine NY

NOV 3 N.Y. 205 Christie St Stanton + WINDISH AGENCY PARTY 6 PM. "Loney, Dear - Live @ 205 (11/03) and White Rabbit (11/04), NYC Prior to Friday's show, I had only been familiar with the thrid Loney, Dear album "Sologne". With SubPop re-releasing the album stateside in February with a few additions, this was a chance for the band to showcase themselves and to get a buzz going. The band opened their CMJ stint with a sold-out showcase for the label, whom they were meeting for the first time. I did not have the chance to attend that show however, but caught the band over the next two days and did they put on a show! The Friday gig at 205 featured them playing a very uptempo set, especially compared to their recorded back-catalogue. The songs hit with a confident pop and swagger, whilst the band themselves were rather reserved, evening during rollicking versions of "The city, the airport" and "Warm, dark, comforting night". Saturday's show saw them in a more intimate performance, focusing on the softer side of things, including an absolutely gorgeous version of "I love you (In with the arms)". With "Loney, noir" seeing release this coming February, I'd expect Loney, Dear to be on everyone's radar for 2007, and if not — they should be.
- Matt Giordano" itsatrap.com

 

MARCH 18 CBGB'S SATURDAY 10:00 PM @ CBGB's, 315 Bowery, New York, NY. "Loney, Dear's Emil Svanängens brought along four bandmembers for this show--a happy medium, considering that the (shakily-Englished) Swedish Showcase press packet made a point of explaining that Loney, Dear's roster ranges from nine all the way down to Svanängens alone. The opening of Loney, Dear's set was marred somewhat by a pair of loud, obnoxious Americans immediately in front of Svanängens, but they slunk away after he kicked their beer off the stage with a booted foot. (Svanängens did not seem disturbed by the group of loud, not-quite-as-obnoxious Swedes standing just as close). Loney, Dear quickly got into the swing of what would prove to be the strongest set of the night. Svanängens' songs were more varied and less derivative of similar artists than any of the other Swedes on the bill and were perfectly overlaid with his clear tenor, which at times might resemble the Counting Crows' Adam Duritz' voice if Duritz were an order of magnitude less whiny and bland. Rarely coming at the audience with an aggressive musical assault, Loney, Dear instead drew in the crowd with plaintive subtlety. "I Fought The Battle of Trinidad and Tobago", from their recently-released album Sologne, was a repetitive but hypnotic and pretty high point of the show, as was "I'm John," which was built around an amazingly beautiful background vocal. "The City, The Airport", a poppy paean to pulling out of an urban center for greener pastures, built to an exulting climax that left the Swedes in the crowd (and hopefully a few New Yorkers, too) wanting much more." indieworkshop.com

MARCH 16. SXSW Austin Thursday 1 PM @ Nudie Jeans Cream Vintage 2532 Guadalupe Austin, TX 78705.

9 FEBRUARI. LINKÖPING (S), HERRGÅRN . Sinister/State of hope!!

Ett alldeles för kort besök
För de flesta band brukar dryga 25 minuter var en lagom lång spelning för att minnet av den inte ska besudlas av tankar om att det var för varmt, för trångt, eller kanske tom långtråkigt. Det finns dock ett fåtal band som man bara vill ska fortsätta med en låt till. Och en till och en till.
Loney, dear. Världens bästa största minsta band. Emil Svanängen är solen och runt honom finner man ibland fem och ibland nio planeter. Det är sant att de inte är helt tajta på HG:s scen men vad gör väl det när när de har fantastiska små men stora låtar som Sinister/state of hope, The city the airport, I do what I can, And I wont cause anything at all och I am John i bagaget? Symbiosen av det lilla och det stora är symptomatiskt för Loney, dear. Ibland är de många på scenen, ibland är de färre. Låtarna är orkestrala men minimala, lågmält poppiga men studsigt dansanta.
Missade ni spelningen eller hade ni inte råd att köpa alla skivor efteråt? Det finns fortfarande chans att göra bot. [...]
26 FEBRUARI SÖDRA TEATERN, STOCKHOLM. SOLD OUT!

Nils Hansson /Dagens Nyheter
Hur många medlemmar har Loney, Dear? Och hur många skivor har de gjort? Två enkla frågor som är ovanligt svåra att svara på. 
Dels för att Loney, Dear på skiva är Emil Svanängen ensam, även om han hittar på diverse musikernamn för att dölja det. Dels för att han i snabb följd har gett ut fyra album på cd-r, varav det tredje just har kommit i nyutgåva på riktigt skivbolag (visserligen hans eget) och det första i en nyinspelad \"redux\"-variant. Det är inte så man normalt gör i pop-Sverige. Hans uttalade ambition är att ge ut två album per år och att bygga upp en publik först, innan han börjar tacka ja till erbjudanden från branschen. Vilket ser ut att redan ha lyckats, att döma av söndagskvällens stora och stormande entusiastiska publik. 
Och på scen blir Loney, Dear ett riktigt, komplett band. Vill det sig väl är de - som nu - hela nio personer, inklusive tre blåsare och en sjungande tamburinflicka. Som spelar så lyhört och flexibelt och finstilt och storslaget att man inte vill tro annat än att det handlar om ett band som har gjort allt tillsammans sedan mellanstadiet. Snarare än det aktuella hopplocket av barndomsvänner, frikyrkomusiker och medlemmar från nyjazzbandet Oskar Schönning. Men musiken är modern indiepop, som hela tiden slits mellan längtan att prata vemod med små bokstäver och lusten att blomma ut i de mest grandiosa popfyrverkerier. Med arrangemang som skiftar fokus hela tiden, fulla av små körer, handklapp, visslingar, påhitt. Samt ett klädbyte för hela bandet. Ändå handlar allt i slutändan om Emil Svanängen [...] och hans älskansvärda sånger, som utan att egentligen likna band som Grandaddy, Mercury Rev, The Hidden Cameras eller Belle & Sebastian ändå gärna för tankarna dit. Kanske just för kombinationen av skör, artistisk känslighet och en sorts pojkaktigt storhetsvansinne i perspektiven. 
Någon småskalig gör-det-självare låter han minst av allt som.

2 DEC VISBY. 26 NOV. Kulturhuset JKPG

18 NOV PUSTERVIK GÖTEBORG. Ibland tar slumpen över och styr mig rätt. Igår var en sådan magisk natt. Nya varma skor och vinterns första kalla, klara natt. 
[…] Det som sedan hände kan beskrivas som känslan när du möter någon som du inte träffat förr men allt stämmer från början. Nyförälskelsens första ljuva sekunder. De få minuter då du känner dig odödlig och morgondagen inte finns. Stunden när alla är ett.
[…] det är i de lite mer lugna låtarna som man verkligen hittar Loney, Dear. 
I en av dem börjar jag sväva. Redan under låtens första sekunder. Jag känner inte golvet mer, väggarna försvinner. Hela den kalla, klara Göteborgshimmelen uppslukar mig och jag blir ett med stjärnorna. Nammmanamma nammanamma. Det är den vackraste sång jag hört. En vaggvisa för vuxna betongsjälar. En tröst för alla som missat vagnen hem. För alla som får gå själva på bio. Sången som en flicka på Hisingen skulle behöva höra just nu. Nammmanamma nammanamma.Jag grät igår med under "Ignorant boy, beautiful girl". För jag vet att jag måste ta farväl av den stunden. Allt annat kommer annars att upphöra, jag kommer inte att få ro. Jag måste släppa den låten. Men det går inte. Nammmanamma nammanamma. Inget kommer mer att bli sig likt. / Jerry

5 NOV. KLOSTRET.

21 OKT KB MALMÖ. Ola, Emil, Samuel, Oscar, Malin, David, Filiph. Fem dearheads åkte från Linköping bara för att höra oss. vackert. Låtlista: I love you. A few good men. I am John. No one can win. Carrying a stone. Where are you go go going to? Trinidad and Tobago. The city, the airport. I do what i can. 20 OKT Kägelbanan, STOCKHOLM. Emil, Malin, David Lindvall, Nils Berg, Samuel, Ola, Filiph Antonsson tonmästare. 30 SEPT Andreas kyrka STOCKHOLM. solo fast med samuel. stor nervositet.  20 SEPT LANDET, telefonplan. antagligen publikrekord i tät kamp med Laleh/Marit tidigare 2005.  4 SEPT (solo) Linköping, Skylten med Second Language/Left handed mfl. 19 AUGUSTI UMEÅ. 11 AUGUSTI. Örebro. Emil och Samuel. 
21 JULI TRÄSTOCK. SKELLEFTEÅ. / dubbelkonsert med SCHÖNNING.  8 JULI ELDSBERGA, HALLAND (solo) Fin spelning solo. Samma dag som: Stockholm/Bromma 6:45 Gränna 10.30. Halmstad 14:00. Oskarshamn 19:50. Visby 23:55. 1000 km på en dag. Rekord.  7 JULI ACCELERATOR Emil, Emil, Nils, Samuel, Oskar, Oscar, Malin, Ola. Roligt. Fullt.  22 JUNI SÖDRA TEATERNS BAR. Det roligaste jag gjort. Har blivit ombedd att ändra åsikt i frågan. Tror att sanningen är att det var väldigt roligt efteråt. Cornelisrummet och Mosebacke 30 maj resp. 14 feb 2005 är roligast ska det vara. Landet är ju ganska roligt också.

6 PM (Windish Agency Party)

28th OCT. HELSINKI Tavasti

Med risk för att låta som en känd företrädare till mig så såg jag svenska bandet Loney Dear i Helsingfors och jag är... drabbad. Uppfylld. Mållös. Jag som knappt gillar livespelningar. Men herreguuud vilket jävla superduperüberkalasbra band. Jag går ner på knä för den bandbokare som lyckas få dem hit. ur XIT.

UK September w/PETER, BJORN & JOHN. 23rd Nottingham Liars Club@ Stealth,

24th Liverpool Bar Academy 
25th London Dingwalls
26th Bristol Lousisana, 27th Brighton Sumo, 28th Derby First Floor club, 29th York Fibbers, 30th Glasgow ABC2. 2nd OCT 6 Music w/Gideon Coe. 2nd OCT radio XFM John Kennedy.

2nd OCT LONDON OLD BLUE LAST. 3rd OCT LONDON DUBLIN CASTLE.

11 July, a small gig at Mosebacke, Stockholm. Thanks for showing up y'all.

CONCERTS with Oscar and Malin: 22 juni Jönköping, 25 juni Malmö, 30 juni Bjärka-Säby, 6 juli Sandvik. 7 juli Halmstad, 16 juli Älvängen, 20 juli Gullbrandstorp, 27 juli Rumskulla, 8 augusti Romelanda, 10 aug Kumla, 12 aug Vasa, 13 aug Söderköping.

17th of June. Back to Jönköping for a faboulous concert on the new-built bridge.
2nd of June. Aarhus, Denmark. A few good men. hard days. and i wont cause 

anything at all. I am John. Trinidad and Tobago. Saturday waits. Carrying a stone. 


28 MAJ STORANS KLUBBSCEN, GÖTEBORG 

En ekvation som smälter hjärtan // av Mattias Agnesund

26 MAJ POPAGANDA, STOCKHOLM. sucky show.

19 MAJ ÖREBRO. FOLKETS HUS. (duo)
70 persons in the audience. Median age 17

5 MAJ LINKÖPING (duo). 
Don't use harsh words. new. 

28 APRIL UPPSALA.

MARCH 16 SXSW AUSTIN, TEXAS @ The Drink, 325 6th St. Austin TX 

MARCH 17 SXSW AUSTIN. Friday March 17, 01:45 PM, VICE PARTY @ VICTORY GRILL 1104 East 11th Street, Time TBA 

 

 
3216 mars 2005. 

13 JUNI SÖDER. Emil och Oskar Schönning samt oskars prao. 
11 JUNI UGGLAN. (!!!!) 30 MAJ Cornelisrummet, Mosebacke.  
22 MAJ HORNSTULLS MJÖLKBAR (trottoaren) Emil, Emil, Oskar, Nils, Malin och Thomas. gäst: Sebastian Voegler (hands) 

 


6 MAJ LANDET TELEFONPLAN 21:30 / SJÖHÄSTEN 23:30. 9-mannaband
Gjorde alltså två gig samma kväll för fulla hus. Nils, Samuel, Thomas, Emil, Oskar, Oscar, Emil, Malin och Ola. Sånger från Loney, Noir framfördes bland annat. En klassiker! 
4 MAJ, FOLKETS HUS ÖREBRO
3 MAJ KAFE 44. 30 APRIL Malmö. 16 APRIL Huskvarna. Emil
3 APRIL Örebro 2 APRIL Linköping. Emil, Ola, Samuel, Oskar, Malin
2 MARS Örebro. 14 Februari. first big one. mosebacke. 
15 JANUARI 2005. Tanto, sucky. ANNO 2004. NOVEMBER 19 /// OSAKA vs TOKYO /// 
OKTOBER 2004. bransch. SEPTEMBER 19 /// UNDERSTANFESTIVALEN /// w/ Oskar Schönning (the band). Plats: tågtunnel under SÖS.

![](concert_13.jpg)

2004 september 4. Hemmahosfestivalen. 2004 juli 24 En ljummen i gräset-festivalen. 2004 juni 19 Trädgården, Sthlm (w/ First Floor Power) 2004 april 23  Kulturhuset, Jönköping. 2004 mars 27. Huskvarna Folketspark (w/ Broder Daniel) 2004 februari 13. P3 popstad2004 i jönköping. 23 januari 2004 debaser. 

6 Februari 2004.  Hobsala.

14 NOV 2003. NORRKÖPING
11 nov 2003 på kafe 44. Kafe mix - Musikmuseet februari 2003. ANNERSKOG! Kafe mix klubb knaster mars 2003. Kafe mix klubb softore april 2003 - 1 här var det varmt och gott 2 here come the lonely ones