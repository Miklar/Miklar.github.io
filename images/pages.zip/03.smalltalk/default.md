---
title: Smalltalk
---

![](emilsgit.jpg)

Emil Svanängen born 1979 is a Swedish musician and composer working under the pseudonym Loney dear. 

Originating from the dark winters and light summer nights of Scandinavia, his music captures heavy emotions and intense energies of something painfully beautiful. In his thought through albums he explores the concept of music itself – through making, releasing and performing.

Emil’s music consists of perfectly composed layers, recorded (one by one) by himself and often performed like that, just by him, his expressive voice and a bunch of instruments. Casually he engineers an entire concert alone, playing sounds with his feet while juggling a bass drum and still being very much present in that moment. Perfection mixed with vibrating flaws makes his music easy to take in and hard to let go.

Spanning over the tiniest detail to grand gestures, linking both to the basic traditions of songs to the great masters. Sometimes Loney Dear grows into a band, letting us play with even more instruments and bigger sounds.

Intrigued in his early childhood by his first synthesizer and the music of Kraftwerk, A-ha and Brian Eno (+jazz, +classical), Emil still plays around with every instrument in any genre he feels like. No one seems quite able to label him – some call it chamber pop, but he’s simply best described as himself.

Emil still gets big kicks out of new instruments, and lately he’s been given orchestras and huge organs to play with which opens for a new chapter of bringing layering and sequencing into the classical world.

Born in the Swedish town of Jönköping, Sweden, Emil works mostly from a house in the country side, still recording everything at home.

Since 2003 Loney Dear has released seven albums, including releases on record labels Sub Pop, Parlophone and the self-own Dear John Recordings, and since 2006 touring around the world together with musicians like Andrew Bird among others.

 

--------

 

I want to tell you something.

![](G2gQYleMCcT8OIjAhEBz9Jw2q8RkD-UkLJHR5qmE7u8-1.jpg)

