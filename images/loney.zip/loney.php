<?php
namespace Grav\Theme;

use Grav\Common\Theme;

class Loney extends Theme
{

}
